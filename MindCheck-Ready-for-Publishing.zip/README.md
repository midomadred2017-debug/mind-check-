# MindCheck — Ready for GitHub Pages
ارفع `index.html` و`privacy.html` و`terms.html` إلى مستودع GitHub عام، ثم فعّل Pages من Settings → Pages → Deploy from a branch → main → / (root).
هذه نسخة Web MVP. الدفع والاشتراكات غير مفعلة، وستحتاج النسخة النهائية للمتجر إلى اختبارات وبيانات متجر وسياسة خصوصية نهائية.